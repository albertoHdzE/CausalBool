"""search-diagnosis-v1 commands (run from ``index-deconvolution/``)::

  PYTHONPATH=experiments:.:../src ../venv/bin/python -m search_diagnosis.cli identity
  ... cli d1                      saved-result map (no encoding)
  ... cli run --section D2|D3|D4  isolated jobs, durable records, resumable
  ... cli analyse                 tables, flags and numbers.json from saved artifacts
  ... cli preserve-after          re-hash protected trees/files, compare with before
"""
from __future__ import annotations

import argparse
import json
import sys
import time

from hierarchy.benchmark import CategoryBudget, environment, sha256_bytes, sha256_file

from . import analysis as A
from . import common as K
from . import runner as R

ATTEMPT = "a1"


def _closure_files() -> list:
    files = sorted(p for p in K.PKG.rglob("*.py") if "__pycache__" not in p.parts)
    files += sorted((K.ID_ROOT / "hierarchy").glob("*.py"))
    files += [K.ID_ROOT / "experiments" / "preserve_confirm_v1_r1_sources.py",
              K.PROTOCOL, K.KICKOFF, K.CONTRACT, K.DELEGATION]
    return files


def _identity_core() -> dict:
    from .kernels import CONFIGS
    rel = lambda p: str(p.relative_to(K.REPO))                     # noqa: E731
    adapters = {rel(p): sha256_file(p) for p in sorted(K.PKG.glob("*.py"))}
    owners = {rel(p): sha256_file(p) for p in sorted((K.ID_ROOT / "hierarchy").glob("*.py"))}
    packet = {rel(p): sha256_file(p) for p in (K.PROTOCOL, K.KICKOFF, K.CONTRACT, K.DELEGATION)}
    design = {"D1": K.design_case_ids(), **{s: K.section_ids(s) for s in ("D2", "D3", "D4")}}
    return {"phase_id": "search-diagnosis-v1", "run_id": K.RUN_ID,
            "evidence_role": K.EVIDENCE_ROLE, "baseline_run": rel(K.BASE_RUN),
            "baseline_freeze_sha256": K.BASE_FREEZE, "adapters": adapters, "owners": owners,
            "packet": packet, "boundary_configs": {k: v.as_dict() for k, v in CONFIGS.items()},
            "limits": {"wall_s": R.WALL_LIMIT_S, "rss_bytes": R.RSS_LIMIT,
                       "max_workers": R.MAX_WORKERS, "allowances_s": R.ALLOWANCES},
            "design_sha256": K.canonical_sha(design)}, design


def cmd_identity(a) -> int:
    d = K.RUN_DIR / "identity"
    core, design = _identity_core()
    sha = K.canonical_sha(core)
    p = d / "identity.json"
    if p.exists():
        old = json.loads(p.read_text())
        if old["identity_sha256"] != sha:
            print(f"identity changed ({old['identity_sha256'][:12]} -> {sha[:12]}): a coding "
                  "repair after launch needs a new attempt id; refusing", file=sys.stderr)
            return 2
        print(f"identity unchanged {sha}")
        return 0
    c = K.contract()
    checks = {"D1_cases": len(design["D1"]), "D2_targets": len(design["D2"]["targets"]),
              "D2_controls": len(design["D2"]["controls"]),
              "D3_strings": len(design["D3"]["targets"]), "D4_strings": len(design["D4"]["targets"])}
    want = {"D1_cases": c["D1"]["cases"], "D2_targets": c["D2"]["target_strings"],
            "D2_controls": c["D2"]["control_strings"], "D3_strings": c["D3"]["strings"],
            "D4_strings": c["D4"]["strings"]}
    if checks != want:
        print(f"design membership {checks} != contract {want}", file=sys.stderr)
        return 2
    refs = K.references()
    cuts_ok = all(len(refs[i]["cuts"]) <= 5 and refs[i]["available"]
                  for i in design["D3"]["targets"])
    inputs = []
    for cid in design["D1"]:
        rows = K.saved_rows(cid)
        case = K.load_case(cid, rows)
        inputs.append({"case_id": cid, "input_sha256": case.input_sha256, "n_bits": len(case.bits),
                       "archives": {m: rows[m]["archive_sha256"] for m in
                                    ("raw", "hid_full", "period", "pair_grammar", "baseline_best")}})
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "_closure_tar", K.ID_ROOT / "experiments" / "preserve_confirm_v1_r1_sources.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.PREFIX = "search-diagnosis-v1-closure/"          # this private instance only
    tar = mod.build_tar([(str(f.relative_to(K.REPO)), f.read_bytes()) for f in _closure_files()])
    d.mkdir(parents=True, exist_ok=True)
    (d / "executable_closure.tar").write_bytes(tar)
    K.write_json(d / "design.json", design)
    (d / "input_manifest.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n"
                                                    for r in inputs))
    K.write_json(d / "environment.json", environment())
    rec = dict(core, identity_sha256=sha, recorded_utc=K.utc(), attempt_id=ATTEMPT,
               membership=checks, d3_supplied_cuts_at_most_5=cuts_ok,
               input_manifest_sha256=sha256_file(d / "input_manifest.jsonl"),
               executable_closure_sha256=sha256_bytes(tar),
               closure_members=len(_closure_files()),
               note="diagnostic implementation identity over ALREADY INSPECTED inputs; not a "
                    "claim that any input is unseen")
    K.write_json(p, rec)
    print(f"identity {sha} ({len(inputs)} inputs, closure {len(tar)} bytes)")
    return 0


def _identity() -> dict:
    rec = json.loads((K.RUN_DIR / "identity" / "identity.json").read_text())
    core, _ = _identity_core()
    if K.canonical_sha(core) != rec["identity_sha256"]:
        raise SystemExit("sources/config/design differ from the recorded identity; refusing")
    return rec


def cmd_d1(a) -> int:
    _identity()
    t0 = time.monotonic()
    d1 = A.d1_map()
    tables = A.d1_tables(d1)
    out = K.RUN_DIR / "d1"
    K.write_json(out / "d1_cases.json", d1["per_case"])
    K.write_json(out / "d1_tables.json", tables)
    K.write_json(out / "d1_checks.json", {"cases": len(d1["ids"]), "rows": d1["rows_read"],
                                          "problems": d1["problems"]})
    R.charge("diagnostic_jobs", "D1 saved-result map", time.monotonic() - t0)
    print(f"D1 cases {len(d1['ids'])} rows {d1['rows_read']} problems {len(d1['problems'])}; "
          f"accepted primary reproduced {tables['accepted_primary_reproduction']['estimate']!r}")
    return 0 if not d1["problems"] else 1


def _jobs(section: str):
    if section == "D2":
        ids = sorted(K.section_ids("D2")["targets"] + K.section_ids("D2")["controls"])
        for cid in ids:
            case = K.load_case(cid)
            yield case, "B0", {}
            yield case, "B8", {}
    elif section == "D3":
        refs = K.references()
        for cid in K.section_ids("D3")["targets"]:
            yield K.load_case(cid), "D3", {"cuts": refs[cid]["cuts"]}
    else:
        for cid in K.section_ids("D4")["targets"]:
            rows = K.saved_rows(cid)
            for m in ("period", "pair_grammar"):
                K.saved_archive(rows[m])                      # hash/length check
            yield K.load_case(cid, rows), "D4", {
                m: str(K.BASE_RUN / rows[m]["archive_path"]) for m in ("period", "pair_grammar")}


def cmd_run(a) -> int:
    ident = _identity()
    budget = CategoryBudget(R.phase_study(), "diagnostic_jobs", f"run {a.section}", K.RUN_ID)
    t = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    stats = R.run_jobs(list(_jobs(a.section)), a.section, ident["identity_sha256"], ATTEMPT,
                       budget=budget, log=(lambda s: None) if a.quiet else print)
    budget.save()
    with open(K.RUN_DIR / "attempts.jsonl", "a") as fh:
        fh.write(json.dumps({"attempt_id": ATTEMPT, "section": a.section, "started_utc": t,
                             "finished_utc": K.utc(), "stats": stats,
                             "identity_sha256": ident["identity_sha256"]}) + "\n")
    print(f"{a.section}: {stats}; diagnostic_jobs used {R.used('diagnostic_jobs'):.1f} s")
    return 0


def cmd_analyse(a) -> int:
    _identity()
    out = K.RUN_DIR / "analysis"
    d2ids = K.section_ids("D2")
    ids2 = sorted(d2ids["targets"] + d2ids["controls"])
    rec2 = A.load_records("D2", ids2, ("B0", "B8"))
    d2 = A.d2_rows(rec2, ids2)
    s2 = A.d2_summary(d2, d2ids["targets"], d2ids["controls"])
    rec3 = A.load_records("D3", d2ids["targets"], ("D3",))
    d3 = A.d3_rows(rec3, d2ids["targets"], d2, K.references())
    ids4 = K.section_ids("D4")["targets"]
    rec4 = A.load_records("D4", ids4, ("D4",))
    d4 = A.d4_rows(rec4, ids4)
    s4 = A.d4_summary(d4, ids4)
    K.write_json(out / "d2_rows.json", d2)
    K.write_json(out / "d2_summary.json", s2)
    K.write_json(out / "d3_rows.json", d3)
    K.write_json(out / "d4_rows.json", d4)
    K.write_json(out / "d4_summary.json", s4)
    K.write_json(out / "resources.json", {"D2": A.resource_summary(rec2),
                                          "D3": A.resource_summary(rec3),
                                          "D4": A.resource_summary(rec4)})
    print(json.dumps({"D2": A.resource_summary(rec2)["status"],
                      "D3": A.resource_summary(rec3)["status"],
                      "D4": A.resource_summary(rec4)["status"]}))
    return 0


def cmd_preserve_after(a) -> int:
    before = json.loads((K.RUN_DIR / "preservation" / "preservation_before.json").read_text())
    after, status = K.preservation_record()
    (K.RUN_DIR / "preservation" / "git_status_after.txt").write_text(status)
    K.write_json(K.RUN_DIR / "preservation" / "preservation_after.json", after)
    cmp = K.compare_preservation(before, after)
    K.write_json(K.RUN_DIR / "preservation" / "preservation_comparison.json", cmp)
    print(json.dumps(cmp))
    return 0 if cmp["unchanged"] else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="search_diagnosis.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("identity").set_defaults(fn=cmd_identity)
    sub.add_parser("d1").set_defaults(fn=cmd_d1)
    r = sub.add_parser("run")
    r.add_argument("--section", choices=("D2", "D3", "D4"), required=True)
    r.add_argument("--quiet", action="store_true")
    r.set_defaults(fn=cmd_run)
    sub.add_parser("analyse").set_defaults(fn=cmd_analyse)
    sub.add_parser("preserve-after").set_defaults(fn=cmd_preserve_after)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
