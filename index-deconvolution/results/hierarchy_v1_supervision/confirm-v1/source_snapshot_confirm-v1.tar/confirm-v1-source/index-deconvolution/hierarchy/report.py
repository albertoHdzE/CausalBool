"""HID-v1 analysis from saved rows only (benchmark annex B4, B6).

Nothing here runs inference. Every number comes from cases.jsonl, the corpus
manifest, diagnostics.json and the archives on disk. Presentation (figures,
notebook prose) lives in notebooks/build_16.py, outside the frozen sources.
"""
from __future__ import annotations

import json
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np

STRUCTURED = ("F01", "F02", "F03", "F04", "F05", "F06", "F12")
CONTROLS = ("F07", "F08", "F09")
ABLATION_METHODS = ("hid_no_schema", "hid_no_arithmetic", "hid_no_transform", "hid_flat",
                    "hid_fixed8")
HID_DEPLOYED = ("ok", "timeout_raw", "rss_limit_raw")      # sizes that count when deployed

ANALYSIS_PLAN = {
    "primary_population": {"split": "confirmation", "families": list(STRUCTURED)},
    "per_string": "saving_bits = baseline_best_archive_bits - hid_full_archive_bits; "
                  "saving_per_input_bit = saving_bits / n_bits",
    "weighting": "mean of the base/ragged pair within a unit, then mean over units in "
                 "each (family, base_length) cell, then mean over cells (equal weights)",
    "primary_bootstrap": {"replicates": 10000, "seed": 33001, "rng": "numpy.random.default_rng",
                          "scheme": "within each cell resample units with replacement, "
                                    "keeping both lengths and all methods together",
                          "interval": "percentile 95%"},
    "verdict": {"supported": "95% interval entirely above 0, all baseline results "
                             "available, engineering gates pass",
                "not_supported": "95% interval entirely below 0",
                "inconclusive": "interval includes 0, or any baseline result censored"},
    "hid_deployed_statuses": list(HID_DEPLOYED),
    "ablations": {"methods": list(ABLATION_METHODS),
                  "per_string": "(ablation_bits - full_bits) / n_bits",
                  "replicates": 10000, "seed": 33002,
                  "interval": "percentile 99% (Bonferroni across five two-sided intervals)",
                  "joint_resampling": True},
    "descriptive": {"family_cells_seed": 33010, "transfer_seed": 33004,
                    "controls_and_all_families": "same endpoint, descriptive only"},
}


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_rows(d: Path) -> list[dict]:
    p = d / "cases.jsonl"
    if not p.exists():
        return []
    return [json.loads(ln) for ln in p.read_text().splitlines() if ln.strip()]


def index_rows(rows):
    """{(split, family, base_length, replicate): {ragged: {method: row}}}."""
    units: dict = defaultdict(lambda: defaultdict(dict))
    for r in rows:
        key = (r["split"], r["family"], r["base_length"], r["replicate"])
        units[key][r["ragged"]][r["method"]] = r
    return units


# ---------------------------------------------------------------------------
# Endpoint arithmetic
# ---------------------------------------------------------------------------

def string_saving(methods: dict) -> tuple[float | None, int | None, str]:
    """(saving per input bit, saving bits, availability) for one scored string."""
    hid = methods.get("hid_full")
    best = methods.get("baseline_best")
    if hid is None or best is None:
        return None, None, "missing_row"
    if hid["status"] not in HID_DEPLOYED or hid["archive_bits"] is None:
        return None, None, f"hid_{hid['status']}"
    if best["status"] != "ok":
        return None, None, f"baseline_{best['status']}"
    sav = best["archive_bits"] - hid["archive_bits"]
    return sav / hid["n_bits"], sav, "ok"


def string_increment(methods: dict, ablation: str) -> float | None:
    full, abl = methods.get("hid_full"), methods.get(ablation)
    if not full or not abl or full["status"] not in HID_DEPLOYED or abl["status"] not in HID_DEPLOYED:
        return None
    return (abl["archive_bits"] - full["archive_bits"]) / full["n_bits"]


def unit_value(pair: dict, fn) -> float | None:
    vals = [fn(pair[r]) for r in (False, True) if r in pair]
    if len(vals) != 2 or any(v is None for v in vals):
        return None
    return (vals[0] + vals[1]) / 2


def cells_matrix(units, split, families, fns) -> tuple[dict, list[str]]:
    """{cell: array(units x len(fns))}; units with any missing value are listed."""
    cells: dict = defaultdict(list)
    missing = []
    for key in sorted(units):
        sp, fam, bl, rep = key
        if sp != split or fam not in families:
            continue
        vec = [unit_value(units[key], fn) for fn in fns]
        if any(v is None for v in vec):
            missing.append(f"{sp}|{fam}|{bl}|{rep}")
            continue
        cells[(fam, bl)].append(vec)
    return {k: np.asarray(v, dtype=float) for k, v in sorted(cells.items())}, missing


def weighted_mean(cells: dict) -> np.ndarray:
    return np.mean([m.mean(axis=0) for m in cells.values()], axis=0)


def stratified_bootstrap(cells: dict, reps: int, seed: int) -> np.ndarray:
    """reps x k matrix of the equal-weight aggregate under within-cell resampling."""
    rng = np.random.default_rng(seed)
    keys = sorted(cells)
    k = next(iter(cells.values())).shape[1]
    acc = np.zeros((reps, k))
    for key in keys:
        m = cells[key]
        idx = rng.integers(0, m.shape[0], size=(reps, m.shape[0]))
        acc += m[idx].mean(axis=1)
    return acc / len(keys)


def percentile_interval(draws: np.ndarray, level: float) -> tuple[float, float]:
    lo = (1 - level) / 2
    return float(np.quantile(draws, lo)), float(np.quantile(draws, 1 - lo))


def verdict(ci: tuple[float, float], baselines_complete: bool, engineering_ok: bool) -> str:
    if ci[1] < 0:
        return "not_supported"
    if ci[0] > 0 and baselines_complete and engineering_ok:
        return "supported"
    return "inconclusive"


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def status_counts(rows, expected: dict) -> dict:
    out = {}
    by = defaultdict(lambda: defaultdict(int))
    for r in rows:
        by[(r["split"], r["method"])][r["status"]] += 1
    methods = sorted({r["method"] for r in rows})
    for split, exp in expected.items():
        per_method = {}
        for m in methods:
            c = dict(by.get((split, m), {}))
            present = sum(c.values())
            per_method[m] = {"expected": exp["scored_strings"], "present": present,
                             "absent": exp["scored_strings"] - present, **c}
        out[split] = per_method
    return out


def describe_cells(units, split, families, seed, level=0.95) -> list[dict]:
    out = []
    rng_seed = seed
    for fam in families:
        for bl in sorted({k[2] for k in units if k[0] == split and k[1] == fam}):
            per, bits, avail = [], [], defaultdict(int)
            unit_vals = []
            for key in sorted(k for k in units if k[:3] == (split, fam, bl)):
                vals = []
                for rg in (False, True):
                    if rg in units[key]:
                        spb, sb, a = string_saving(units[key][rg])
                        avail[a] += 1
                        if spb is not None:
                            per.append(spb)
                            bits.append(sb)
                            vals.append(spb)
                if len(vals) == 2:
                    unit_vals.append(sum(vals) / 2)
            row = {"family": fam, "base_length": bl, "units_complete": len(unit_vals),
                   "availability": dict(avail)}
            if unit_vals:
                arr = np.asarray(unit_vals)
                rng = np.random.default_rng(rng_seed)
                draws = arr[rng.integers(0, len(arr), size=(10000, len(arr)))].mean(axis=1)
                row.update({
                    "mean_saving_per_input_bit": float(arr.mean()),
                    "ci95_descriptive": percentile_interval(draws, level),
                    "mean_saving_bits": float(np.mean(bits)),
                    "median_saving_bits": float(np.median(bits)),
                    "median_saving_per_input_bit": float(np.median(per)),
                    "strings_hid_better": int(sum(b > 0 for b in bits)),
                    "strings_tied": int(sum(b == 0 for b in bits)),
                    "strings_hid_worse": int(sum(b < 0 for b in bits))})
            rng_seed += 1
            out.append(row)
    return out


def resources(rows) -> dict:
    out = {}
    for m in sorted({r["method"] for r in rows}):
        rr = [r for r in rows if r["method"] == m]
        enc = [r["encode_wall_ns"] / 1e9 for r in rr if r["encode_wall_ns"] is not None]
        wk = [r["worker_wall_ns"] / 1e9 for r in rr if r["worker_wall_ns"] is not None]
        rss = [r["peak_rss_bytes"] for r in rr if r["peak_rss_bytes"] is not None]
        out[m] = {"encode_s_median": statistics.median(enc) if enc else None,
                  "encode_s_max": max(enc) if enc else None,
                  "encode_s_total": sum(enc) if enc else None,
                  "worker_s_total": sum(wk) if wk else None,
                  "peak_rss_mb_max": max(rss) / 2 ** 20 if rss else None}
    return out


def summarise(d: Path, expected: dict, engineering: dict,
              primary_split: str = "confirmation") -> dict:
    """``primary_split`` is "confirmation" for every confirmatory run; development
    runs use "development" and are labelled exploratory by their callers."""
    rows = load_rows(d)
    units = index_rows(rows)
    dec = {"decode_ok": sum(1 for r in rows if r["decode_ok"] is True),
           "decode_failed": sum(1 for r in rows if r["decode_ok"] is False),
           "with_archive": sum(1 for r in rows if r["archive_path"])}
    summary = {"analysis_plan": ANALYSIS_PLAN, "status_counts": status_counts(rows, expected),
               "round_trips": dec, "engineering": engineering}
    eng_ok = engineering.get("valid", False)

    # primary endpoint
    cells, missing = cells_matrix(units, primary_split, STRUCTURED, [string_saving_pb])
    base_censored = sorted({f"{r['case_id']}:{r['status']}" for r in rows
                            if r["split"] == primary_split and r["family"] in STRUCTURED
                            and r["method"] == "baseline_best" and r["status"] != "ok"})
    if cells:
        point = float(weighted_mean(cells)[0])
        draws = stratified_bootstrap(cells, 10000, 33001)[:, 0]
        ci = percentile_interval(draws, 0.95)
        complete = not missing and not base_censored
        summary["primary"] = {
            "split": primary_split,
            "estimate_mean_saving_per_input_bit": point, "ci95": ci,
            "bootstrap": {"replicates": 10000, "seed": 33001,
                          "draw_mean": float(draws.mean()), "draw_sd": float(draws.std())},
            "cells": len(cells), "units": int(sum(m.shape[0] for m in cells.values())),
            **_string_level(units, primary_split),
            "units_missing": missing, "baseline_not_ok": base_censored,
            "verdict": verdict(ci, complete, eng_ok)}
    else:
        summary["primary"] = {"verdict": "inconclusive", "reason": "no confirmation rows",
                              "units_missing": missing}

    # ablations, jointly resampled
    fns = [(lambda m, a=a: string_increment(m, a)) for a in ABLATION_METHODS]
    acells, amissing = cells_matrix(units, primary_split, STRUCTURED, fns)
    if acells:
        point = weighted_mean(acells)
        draws = stratified_bootstrap(acells, 10000, 33002)
        summary["ablations"] = {}
        for i, a in enumerate(ABLATION_METHODS):
            ci = percentile_interval(draws[:, i], 0.99)
            summary["ablations"][a] = {
                "incremental_gain_per_input_bit": float(point[i]), "ci99": ci,
                "component_advantage": "supported" if ci[0] > 0 else (
                    "ablation_better" if ci[1] < 0 else "not_detected")}
        summary["ablations_units_missing"] = amissing

    # descriptive tables
    summary["families_confirmation"] = describe_cells(
        units, "confirmation", tuple(f"F{i:02d}" for i in range(1, 13)), 33010)
    summary["transfer"] = describe_cells(units, "transfer",
                                         tuple(f"F{i:02d}" for i in range(1, 13)), 33004)
    tcells, tmissing = cells_matrix(units, "transfer", STRUCTURED, [string_saving_pb])
    if tcells:
        tp = float(weighted_mean(tcells)[0])
        td = stratified_bootstrap(tcells, 10000, 33005)[:, 0]
        summary["transfer_structured_aggregate"] = {
            "estimate": tp, "ci95_descriptive": percentile_interval(td, 0.95),
            "units_missing": tmissing, "note": "descriptive; four units per cell"}
    ccells, _ = cells_matrix(units, primary_split, CONTROLS, [string_saving_pb])
    if ccells:
        cd = stratified_bootstrap(ccells, 10000, 33006)[:, 0]
        summary["controls_aggregate"] = {"estimate": float(weighted_mean(ccells)[0]),
                                         "ci95_descriptive": percentile_interval(cd, 0.95)}
    summary["development"] = describe_cells(units, "development",
                                            tuple(f"F{i:02d}" for i in range(1, 13)), 33020)
    summary["resources"] = resources(rows)
    hashes = defaultdict(list)
    for r in rows:
        if r["method"] == "hid_full":
            hashes[r["input_sha256"]].append(r["case_id"])
    summary["duplicate_inputs"] = {h: ids for h, ids in hashes.items() if len(ids) > 1}
    summary["selected_baselines"] = _selected_counts(rows)
    summary["hid_stop_reasons"] = _stop_counts(rows)
    return summary


def _string_level(units, split) -> dict:
    per, bits = [], []
    for key, pair in units.items():
        if key[0] == split and key[1] in STRUCTURED:
            for rg in pair.values():
                spb, sb, a = string_saving(rg)
                if spb is not None:
                    per.append(spb)
                    bits.append(sb)
    if not bits:
        return {}
    return {"strings": len(bits), "mean_saving_bits": float(np.mean(bits)),
            "median_saving_bits": float(np.median(bits)),
            "mean_saving_per_input_bit_unweighted": float(np.mean(per)),
            "median_saving_per_input_bit": float(np.median(per)),
            "strings_hid_better": int(sum(b > 0 for b in bits)),
            "strings_tied": int(sum(b == 0 for b in bits)),
            "strings_hid_worse": int(sum(b < 0 for b in bits))}


def representative_ledgers(d: Path, rows) -> list[dict]:
    """One case per (split, family, base_length): lowest replicate, base length,
    the HID-full archive and the portfolio's selected archive, with byte ledgers
    read from the stored bytes and the decoded expansion cross-checked."""
    from .decode import decode_archive
    from .ledger import archive_ledger, explain_model
    pick: dict = {}
    for r in rows:
        if r["ragged"] or r["method"] not in ("hid_full", "baseline_best") or not r["archive_path"]:
            continue
        key = (r["split"], r["family"], r["base_length"])
        cur = pick.get(key, {}).get("replicate")
        if cur is None or r["replicate"] < cur:
            pick[key] = {"replicate": r["replicate"]}
        if r["replicate"] == pick[key]["replicate"]:
            pick[key][r["method"]] = r
    out = []
    for key in sorted(pick):
        entry = {"split": key[0], "family": key[1], "base_length": key[2],
                 "replicate": pick[key]["replicate"]}
        for m in ("hid_full", "baseline_best"):
            r = pick[key].get(m)
            if r is None:
                continue
            data = (d / r["archive_path"]).read_bytes()
            led = archive_ledger(data)
            decoded = decode_archive(data)
            item = {"case_id": r["case_id"], "input_sha256": r["input_sha256"],
                    "archive_sha256": r["archive_sha256"], "archive_bits": 8 * len(data),
                    "codec": led["codec"], "bytes_by_owner": led["bytes_by_owner"],
                    "ledger_sum_bits": 8 * sum(f["bytes"] for f in led["fields"]),
                    "fields": led["fields"] if len(led["fields"]) <= 400 else
                    led["fields"][:400] + [{"truncated": len(led["fields"]) - 400}],
                    "decoded_sha256": _sha(decoded)}
            if led["model"] is not None:
                if led["model"].expand() != decoded:
                    raise AssertionError("encoder evaluator and decoder disagree")
                item["graph"] = explain_model(led["model"])
            entry[m] = item
        out.append(entry)
    return out


def _sha(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode("ascii")).hexdigest()


def string_saving_pb(methods):
    return string_saving(methods)[0]


def _selected_counts(rows) -> dict:
    out = defaultdict(lambda: defaultdict(int))
    for r in rows:
        if r["method"] == "baseline_best" and r["selected_method"]:
            out[f"{r['split']}|{r['family']}"][r["selected_method"]] += 1
    return {k: dict(v) for k, v in sorted(out.items())}


def _stop_counts(rows) -> dict:
    out = defaultdict(lambda: defaultdict(int))
    for r in rows:
        if r["method"].startswith("hid_"):
            out[f"{r['split']}|{r['method']}"][str(r["stop_reason"] or r["status"])] += 1
    return {k: dict(v) for k, v in sorted(out.items())}


# ---------------------------------------------------------------------------
# Claim ledger
# ---------------------------------------------------------------------------

def claim_ledger(summary: dict, diagnostics: dict | None, run_id: str) -> list[dict]:
    led = []
    p = summary.get("primary", {})
    led.append({
        "id": "C1", "claim": "HID-v1 (full) yields an average code-length gain over the "
                             "strong decodable baseline portfolio on the prespecified "
                             "structured confirmation benchmark",
        "status": p.get("verdict", "inconclusive"),
        "metric": "equal-family, equal-size mean of (baseline_best_bits - hid_full_bits)/n",
        "estimate": p.get("estimate_mean_saving_per_input_bit"), "uncertainty": p.get("ci95"),
        "evidence": [f"results/hierarchy_v1/{run_id}/summary.json#primary",
                     f"results/hierarchy_v1/{run_id}/cases.jsonl (split=confirmation, "
                     f"families {','.join(STRUCTURED)}, methods hid_full, baseline_best)"],
        "domain": "families F01-F06, F12; base lengths 256, 1024, 4096 plus ragged +3; "
                  "replicates 1000-1019; frozen search budget",
        "caveat": "a code-length comparison under a fixed language and budget; not K, not "
                  "generator recovery, not prediction"})
    eng = summary.get("engineering", {})
    rt = summary.get("round_trips", {})
    led.append({
        "id": "C2", "claim": "Every stored archive decodes exactly to its input with the "
                             "independent decoder",
        "status": "supported" if eng.get("valid") and rt.get("decode_failed") == 0 else "not_supported",
        "metric": "decode_ok rows / rows with an archive", "estimate": rt,
        "uncertainty": None,
        "evidence": [f"results/hierarchy_v1/{run_id}/verification.json"],
        "domain": "all splits run under this run id", "caveat": "engineering claim"})
    for i, (a, v) in enumerate(sorted(summary.get("ablations", {}).items())):
        st = {"supported": "supported", "ablation_better": "not_supported",
              "not_detected": "inconclusive"}[v["component_advantage"]]
        led.append({
            "id": f"C3.{i + 1}", "claim": f"The component removed in {a} contributes a "
                                          "code-length advantage to the full search",
            "status": st, "metric": "equal-weight mean of (ablation_bits - full_bits)/n",
            "estimate": v["incremental_gain_per_input_bit"], "uncertainty": v["ci99"],
            "evidence": [f"results/hierarchy_v1/{run_id}/summary.json#ablations.{a}"],
            "domain": "structured confirmation population",
            "caveat": "99% Bonferroni intervals; an ablation can win through search interaction"})
    t = summary.get("transfer_structured_aggregate")
    if t:
        lo, hi = t["ci95_descriptive"]
        led.append({
            "id": "C4", "claim": "The structured-family result transfers to 16384 and 65536 bits",
            "status": "supported" if lo > 0 else ("not_supported" if hi < 0 else "inconclusive"),
            "metric": "same endpoint on the transfer split", "estimate": t["estimate"],
            "uncertainty": t["ci95_descriptive"],
            "evidence": [f"results/hierarchy_v1/{run_id}/summary.json#transfer_structured_aggregate"],
            "domain": "four units per family/size", "caveat": "descriptive only"})
    c = summary.get("controls_aggregate")
    if c:
        led.append({
            "id": "C5", "claim": "HID-v1 shows no advantage over the statistical baselines on "
                                 "IID, biased IID and Markov controls",
            "status": "supported" if c["ci95_descriptive"][1] <= 0 else "not_supported",
            "metric": "same endpoint on F07-F09", "estimate": c["estimate"],
            "uncertainty": c["ci95_descriptive"],
            "evidence": [f"results/hierarchy_v1/{run_id}/summary.json#controls_aggregate"],
            "domain": "confirmation F07-F09", "caveat": "descriptive"})
    if diagnostics:
        led.append({
            "id": "C6", "claim": "Aligned/full-coverage BDM, with setting selection calibrated "
                                 "symmetrically on marginal-preserving nulls, separates the "
                                 "structured diagnostic objects from bit shuffles",
            "status": diagnostics.get("claim_status", "inconclusive"),
            "metric": "adaptive p-value (r+1)/(B+1), Holm-adjusted across ten objects",
            "estimate": {k: v["adaptive_p"] for k, v in diagnostics.get("objects", {}).items()},
            "uncertainty": "Monte Carlo, 199 nulls",
            "evidence": [f"results/hierarchy_v1/{run_id}/diagnostics.json"],
            "domain": "replicate 1000, base length 1024, non-ragged",
            "caveat": "marginal shuffle null; says nothing beyond bit marginals for F09; "
                      "BDM is a diagnostic score, never stored bytes"})
    for cid, text in (("C7", "HID-v1 computes or estimates Kolmogorov complexity"),
                      ("C8", "An inferred description is the unique generating mechanism"),
                      ("C9", "Full-string compression establishes prediction of unseen suffixes"),
                      ("C10", "The study establishes causal identification or priority of "
                              "hierarchical grammar coding")):
        led.append({"id": cid, "claim": text, "status": "out_of_scope", "metric": None,
                    "estimate": None, "uncertainty": None, "evidence": [
                        "PROTOCOL_hierarchical_index_generalization.md section 1"],
                    "domain": None, "caveat": "not tested by this design"})
    return led
