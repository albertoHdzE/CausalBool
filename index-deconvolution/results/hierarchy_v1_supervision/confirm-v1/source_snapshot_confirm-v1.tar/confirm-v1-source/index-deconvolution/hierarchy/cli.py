"""HID-v1 command line (orchestration only).

Run from the repository root with PYTHONPATH=index-deconvolution:src:

  python -m hierarchy.cli selfcheck
  python -m hierarchy.cli pilot --run-id dev-v1
  python -m hierarchy.cli freeze --run-id confirm-v1
  python -m hierarchy.cli benchmark --run-id confirm-v1 --split confirmation --resume
  python -m hierarchy.cli benchmark --run-id confirm-v1 --split transfer --resume
  python -m hierarchy.cli diagnostics --run-id confirm-v1
  python -m hierarchy.cli report --run-id confirm-v1
  python -m hierarchy.cli verify --run-id confirm-v1
  python -m hierarchy.cli encode --input bits.txt --output bits.isd
  python -m hierarchy.cli decode --input bits.isd --output bits.txt

verify exits 0 for a complete, valid study (whatever its scientific verdict),
2 for engineering invalidity or corrupted/missing artefacts, 3 for an incomplete
declared split.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

EXIT_OK, EXIT_INVALID, EXIT_INCOMPLETE = 0, 2, 3


def _read_bits_file(path: Path) -> str:
    raw = path.read_bytes()
    if raw.endswith(b"\n"):
        raw = raw[:-1]
    if raw.strip(b"01"):
        raise SystemExit("input must contain only ASCII 0/1 (one terminal newline allowed)")
    return raw.decode("ascii")


def cmd_encode(a) -> int:
    from .infer import infer
    from .benchmark import atomic_write
    bits = _read_bits_file(Path(a.input))
    res = infer(bits)
    atomic_write(Path(a.output), res.archive)
    print(json.dumps({"n_bits": len(bits), "archive_bits": res.archive_bits,
                      "literal_bits": res.literal_bits, "mode": res.mode,
                      "stop_reason": res.stop_reason}))
    return 0


def cmd_decode(a) -> int:
    from .decode import decode_archive
    from .benchmark import atomic_write
    bits = decode_archive(Path(a.input).read_bytes())
    atomic_write(Path(a.output), bits.encode("ascii"))
    return 0


def cmd_selfcheck(a) -> int:
    from .baselines import BASELINE_METHODS, encode_baseline
    from .decode import decode_archive
    from .infer import ABLATIONS, infer
    from .model import Literal, Model, Repeat
    from .wire import encode_literal, serialize_model
    checks = {}
    checks["golden_hid"] = serialize_model(Model((Literal("1"), Repeat(0, 8))), 8).hex() == \
        "4953443101080702000180020008"
    checks["golden_literal"] = encode_literal("0110").hex() == "4953443100040160"
    smoke = ["", "1", "0110" * 20, ("1" * 8 + "0") * 8, "1011001110001111" * 9 + "01"]
    ok = True
    for s in smoke:
        for m in BASELINE_METHODS:
            ok &= decode_archive(encode_baseline(s, m)) == s
        for cfg in ABLATIONS.values():
            r = infer(s, cfg)
            ok &= decode_archive(r.archive) == s and r.archive_bits <= r.literal_bits
    checks["smoke_round_trips"] = ok
    with tempfile.TemporaryDirectory() as tmp:
        from . import decode as dmod
        shutil.copy(dmod.__file__, Path(tmp) / "decode.py")
        arc = infer(smoke[3]).archive
        (Path(tmp) / "a.bin").write_bytes(arc)
        out = subprocess.run([sys.executable, "-I", "-S", "decode.py", "a.bin"], cwd=tmp,
                             env={"PATH": os.environ.get("PATH", "")},
                             capture_output=True, text=True)
        checks["separate_process_decoder"] = (
            out.returncode == 0 and json.loads(out.stdout)[0]["bits"] == smoke[3])
    print(json.dumps(checks, indent=1))
    return 0 if all(checks.values()) else 1


def cmd_pilot(a) -> int:
    from . import benchmark as B
    from . import report as R
    from .corpus import expected_counts, split_cases
    d = B.run_dir(a.run_id)
    if not a.run_id.startswith("dev"):
        raise SystemExit("pilot run ids must start with 'dev'")
    d.mkdir(parents=True, exist_ok=True)
    log = d / "logs"
    log.mkdir(exist_ok=True)
    t0 = time.time()
    if not (d / "rows").exists():
        # Deliberate interruption, then resume: the resume path is exercised for real.
        B.benchmark(a.run_id, "development", resume=False, stop_after=a.interrupt_after,
                    require_freeze=False)
    B.benchmark(a.run_id, "development", resume=True, require_freeze=False)
    # Fresh uninterrupted replay of the first cases, compared field by field.
    cases, _ = split_cases("development")
    replay_id = a.run_id + "-replay"
    rd = B.run_dir(replay_id)
    if rd.exists():
        shutil.rmtree(rd)
    rd.mkdir(parents=True)
    B.run_cases(cases[:a.replay_cases], rd, replay_id, "development-unfrozen", False,
                lambda m: None)
    det = ("status", "archive_sha256", "archive_bits", "decode_ok", "selected_codec_id",
           "selected_method", "rule_count", "dag_depth", "candidate_count",
           "deterministic_work", "stop_reason", "search_counters", "trace")
    diffs = []
    for c in cases[:a.replay_cases]:
        x = {r["method"]: r for r in json.loads(B.case_rows_path(d, c).read_text())}
        y = {r["method"]: r for r in json.loads(B.case_rows_path(rd, c).read_text())}
        for m in x:
            for k in det:
                if x[m][k] != y[m][k]:
                    diffs.append({"case": c.case_id, "method": m, "field": k})
    B.atomic_write(d / "resume_check.json", json.dumps({
        "interrupted_after_cases": a.interrupt_after, "replayed_cases": a.replay_cases,
        "deterministic_fields": det, "differences": diffs,
        "identical": not diffs}, indent=1).encode())
    print(f"resume/replay identical: {not diffs} ({len(diffs)} differences)")
    if a.oracle:
        res = B.run_oracle(d / "oracle.json")
        print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk not in ("rows", "examples")}
                          for k, v in res["tables"].items()}))
    eng = _engineering(d, ["development"], frozen=False)
    summary = R.summarise(d, {"development": expected_counts()["development"]}, eng)
    summary["status"] = "development pilot (exploratory, not confirmatory)"
    B.atomic_write(d / "summary.json", json.dumps(summary, indent=1, default=float).encode())
    print(f"pilot done in {time.time() - t0:.0f} s; rows in {d}")
    return 0


def cmd_freeze(a) -> int:
    from . import benchmark as B
    fr = B.write_freeze(a.run_id)
    print(f"froze {a.run_id}: sha256 {B.freeze_sha(fr)}")
    return 0


def cmd_benchmark(a) -> int:
    from . import benchmark as B
    allowed = ("development",) if a.run_id.startswith("dev") else ("confirmation", "transfer")
    if a.split not in allowed:
        raise SystemExit(f"run id {a.run_id} may benchmark only {allowed}")
    stats = B.benchmark(a.run_id, a.split, a.resume, log=print if not a.quiet else (lambda m: None))
    print(json.dumps(stats))
    return 0


def cmd_diagnostics(a) -> int:
    from . import benchmark as B
    from . import diagnostics as D
    fr, fsha, problems = B.load_and_validate_freeze(a.run_id)
    if problems:
        raise SystemExit("freeze validation failed: " + "; ".join(problems))
    d = B.run_dir(a.run_id)
    t0 = time.time()
    if a.run_id.startswith("dev"):         # pipeline smoke run: development data only
        from .corpus import HELD_OUT
        out = D.run(workers=B.MAX_WORKERS, split="development", replicate=0,
                    families=tuple(f for f in D.DIAG_FAMILIES if f not in HELD_OUT))
    else:
        out = D.run(workers=B.MAX_WORKERS)
    out["freeze_sha256"] = fsha
    out["historical_audit33"] = {
        "path": "diagnostics_historical_audit33.json",
        "note": "bitacora-33 audit rerun to a new path; the original JSON is untouched"}
    D.historical_audit(d / "diagnostics_historical_audit33.json")
    out["wall_s"] = time.time() - t0
    B.atomic_write(d / "diagnostics.json", json.dumps(out, indent=1).encode())
    budget = B.Budget(d, B.TOTAL_BUDGET_S)
    budget.used += out["wall_s"]
    budget.save()
    print(f"diagnostics written; claim status {out['claim_status']}")
    return 0


def _engineering(d: Path, splits, frozen: bool, run_id: str | None = None) -> dict:
    from . import benchmark as B
    from . import report as R
    problems = []
    if frozen:
        _, _, fp = B.load_and_validate_freeze(run_id)
        problems += fp
    rows = R.load_rows(d)
    rows = [r for r in rows if r["split"] in splits]
    errors = [r["case_id"] + ":" + r["method"] for r in rows if r["status"] == "error"]
    bad_decode = [r["case_id"] + ":" + r["method"] for r in rows if r["decode_ok"] is False]
    return {"valid": not problems and not errors and not bad_decode,
            "freeze_problems": problems, "error_rows": errors, "wrong_decodes": bad_decode}


def cmd_report(a) -> int:
    from . import benchmark as B
    from . import report as R
    from .corpus import expected_counts
    d = B.run_dir(a.run_id)
    splits = _splits(a.run_id)
    eng = _engineering(d, splits, frozen=True, run_id=a.run_id)
    exp = {s: expected_counts()[s] for s in splits}
    summary = R.summarise(d, exp, eng, primary_split=splits[0])
    diag = json.loads((d / "diagnostics.json").read_text()) if (d / "diagnostics.json").exists() else None
    if diag:
        summary["bdm_diagnostics"] = {f: {k: v for k, v in o.items()
                                          if k in ("adaptive_p", "selected_config", "T0",
                                                   "r_null_at_or_below")}
                                      for f, o in diag["objects"].items()}
        summary["bdm_holm"] = diag["holm"]
    complete = all(v.get("absent", 0) == 0 and v.get("not_run", 0) == 0
                   for s in summary["status_counts"].values() for v in s.values())
    summary["study_complete"] = complete
    summary["engineering_status"] = "valid" if eng["valid"] else "invalid"
    summary["scientific_verdict"] = summary.get("primary", {}).get("verdict")
    B.atomic_write(d / "summary.json", json.dumps(summary, indent=1, default=float).encode())
    rows = R.load_rows(d)
    B.atomic_write(d / "ledgers.json", json.dumps(R.representative_ledgers(d, rows), indent=1).encode())
    led = R.claim_ledger(summary, diag, a.run_id)
    B.atomic_write(d / "claim_ledger.json", json.dumps(led, indent=1, default=float).encode())
    print(json.dumps({"engineering": summary["engineering_status"], "complete": complete,
                      "verdict": summary["scientific_verdict"],
                      "primary": {k: summary.get("primary", {}).get(k)
                                  for k in ("estimate_mean_saving_per_input_bit", "ci95")}},
                     default=float))
    return 0


def cmd_verify(a) -> int:
    """Read-only verification of a stored run (writes only verification.json)."""
    from . import benchmark as B
    from . import report as R
    from .corpus import expected_counts, split_cases
    from .decode import decode_archive
    d = B.run_dir(a.run_id)
    v = {"run_id": a.run_id, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
         "commands": [], "problems": []}
    try:
        fr, fsha, fp = B.load_and_validate_freeze(a.run_id)
        v["freeze_sha256"] = fsha
        v["freeze_problems"] = fp
    except FileNotFoundError:
        v["problems"].append("freeze.json missing")
        fp = ["missing"]
        fsha = None
    rows = R.load_rows(d)
    splits = _splits(a.run_id)
    incomplete = []
    invalid = list(fp)
    by_case = {}
    for r in rows:
        by_case.setdefault(r["case_id"], {})[r["method"]] = r
    decoded = 0
    mismatched_inputs = 0
    for split in splits:
        cases, _ = split_cases(split)
        exp = expected_counts()[split]["scored_strings"]
        present = 0
        for c in cases:
            rr = by_case.get(c.case_id)
            if not rr or len(rr) != len(B.ALL_METHODS):
                continue
            present += 1
            for m, r in rr.items():
                if r["input_sha256"] != c.input_sha256:
                    mismatched_inputs += 1
                if r["freeze_sha256"] != fsha:
                    invalid.append(f"{c.case_id}:{m} freeze hash differs")
                if r["status"] == "not_run":
                    incomplete.append(f"{c.case_id}:{m} not_run")
                if r["status"] == "error":
                    invalid.append(f"{c.case_id}:{m} error row")
                if not r["archive_path"]:
                    continue
                p = d / r["archive_path"]
                if not p.exists():
                    invalid.append(f"{c.case_id}:{m} archive missing")
                    continue
                data = p.read_bytes()
                if B.sha256_bytes(data) != r["archive_sha256"]:
                    invalid.append(f"{c.case_id}:{m} archive hash mismatch")
                    continue
                if 8 * len(data) != r["archive_bits"]:
                    invalid.append(f"{c.case_id}:{m} archive_bits differs from bytes")
                if m == "baseline_best":
                    continue
                try:
                    ok = decode_archive(data) == c.bits
                except Exception as exc:                     # noqa: BLE001 -- reported
                    ok = False
                    invalid.append(f"{c.case_id}:{m} decoder raised {type(exc).__name__}")
                if not ok:
                    invalid.append(f"{c.case_id}:{m} wrong decode")
                decoded += 1
            best = rr.get("baseline_best")
            if best and best["status"] == "ok":
                cons = {m: rr[m]["archive_bits"] for m in R_BASELINES()}
                want = min(cons.values())
                if best["archive_bits"] != want:
                    invalid.append(f"{c.case_id}: portfolio is not the constituent minimum")
        if present < exp:
            incomplete.append(f"{split}: {present}/{exp} scored strings complete")
    v["archives_decoded_against_regenerated_inputs"] = decoded
    v["input_hash_mismatches"] = mismatched_inputs
    if mismatched_inputs:
        invalid.append("regenerated corpus does not match stored input hashes")
    v["separate_process_decode"] = _separate_process_sample(d, rows)
    if not v["separate_process_decode"]["all_ok"]:
        invalid.append("separate-process decoder disagreed on the stratified sample")
    for name in ("summary.json", "claim_ledger.json", "diagnostics.json", "corpus_manifest.jsonl",
                 "cases.jsonl", "freeze.json"):
        if not (d / name).exists():
            invalid.append(f"required artefact missing: {name}")
    summ = json.loads((d / "summary.json").read_text()) if (d / "summary.json").exists() else {}
    v["scientific_verdict"] = summ.get("scientific_verdict")
    v["engineering_status"] = "invalid" if invalid else "valid"
    v["completeness"] = "incomplete" if incomplete else "complete"
    v["invalid_reasons"] = invalid[:200]
    v["incomplete_reasons"] = incomplete[:200]
    if a.full:
        v["commands"] = _run_checks()
        if any(c["exit_code"] != 0 for c in v["commands"] if c.get("required", True)):
            v["problems"].append("a required check command failed")
    v["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    code = EXIT_INVALID if invalid else (EXIT_INCOMPLETE if incomplete else EXIT_OK)
    if v["problems"] and code == EXIT_OK:
        code = EXIT_INVALID
    v["exit_code"] = code
    out = d / "verification.json"
    tmp = out.with_name(".verification.json.tmp")
    tmp.write_text(json.dumps(v, indent=1))
    os.replace(tmp, out)
    print(json.dumps({k: v[k] for k in ("engineering_status", "completeness",
                                        "scientific_verdict", "exit_code",
                                        "archives_decoded_against_regenerated_inputs")}))
    return code


def _splits(run_id: str) -> list[str]:
    return ["development"] if run_id.startswith("dev") else ["confirmation", "transfer"]


def R_BASELINES():
    from .baselines import BASELINE_METHODS
    return BASELINE_METHODS


def _separate_process_sample(d: Path, rows) -> dict:
    """Decode one archive per (split, family, method) with only decode.py present."""
    from . import decode as dmod
    from .corpus import split_cases
    want = {}
    for r in rows:
        if r["archive_path"] and r["method"] != "baseline_best":
            key = (r["split"], r["family"], r["method"], r["status"])
            want.setdefault(key, r)
    inputs = {}
    for split in {k[0] for k in want}:
        for c in split_cases(split)[0]:
            inputs[c.case_id] = c.bits
    with tempfile.TemporaryDirectory() as tmp:
        box = Path(tmp)
        shutil.copy(dmod.__file__, box / "decode.py")
        names = {}
        for i, r in enumerate(want.values()):
            name = f"s{i:05d}.bin"
            shutil.copy(d / r["archive_path"], box / name)
            names[name] = r
        if not names:
            return {"sampled": 0, "all_ok": False}
        out = subprocess.run([sys.executable, "-I", "-S", "decode.py"] + sorted(names),
                             cwd=box, env={"PATH": os.environ.get("PATH", "")},
                             capture_output=True, text=True)
        res = json.loads(out.stdout) if out.returncode == 0 else []
    ok = [x["ok"] and x["bits"] == inputs[names[x["path"]]["case_id"]] for x in res]
    return {"sampled": len(names), "decoded": len(res), "all_ok": bool(res) and all(ok)
            and len(res) == len(names),
            "strata": "one archive per (split, family, method, status), including fallbacks"}


def _run_checks() -> list[dict]:
    repo = Path(__file__).resolve().parents[2]
    env = dict(os.environ, PYTHONPATH=f"{repo / 'index-deconvolution'}{os.pathsep}{repo / 'src'}")
    cmds = [
        ("pytest", [sys.executable, "-m", "pytest", "index-deconvolution/hierarchy/tests",
                    "tests/analysis/test_description_lengths_values.py", "-q", "--tb=short",
                    "-p", "no:cacheprovider"], True),
        ("ruff", ["ruff", "check", "--output-format=concise", "index-deconvolution/hierarchy",
                  "src/description_lengths.py", "tests/analysis/test_description_lengths_values.py",
                  "index-deconvolution/notebooks/build_15.py",
                  "index-deconvolution/notebooks/build_16.py"], True),
        ("check_core_index", ["zsh", "tools/check_core_index.sh"], True),
        ("check_test_manifest", ["zsh", "tools/check_test_manifest.sh"], False),
        ("check_single_engine", ["zsh", "tools/check_single_engine.sh"], False),
    ]
    out = []
    for name, cmd, required in cmds:
        t0 = time.time()
        p = subprocess.run(cmd, cwd=repo, env=env, capture_output=True, text=True)
        tail = (p.stdout + p.stderr).strip().splitlines()[-3:]
        out.append({"name": name, "command": " ".join(cmd[1:] if cmd[0] == sys.executable
                                                      else cmd),
                    "exit_code": p.returncode, "tail": tail, "seconds": round(time.time() - t0, 1),
                    "required": required})
    for nb in ("15_shifted_zero_bdm_probe.ipynb", "16_hierarchical_index_generalization.ipynb"):
        path = repo / "index-deconvolution" / "notebooks" / nb
        if not path.exists():
            out.append({"name": f"notebook {nb}", "exit_code": 1, "tail": ["missing"],
                        "required": True})
            continue
        cells = json.loads(path.read_text())["cells"]
        code = [c for c in cells if c["cell_type"] == "code"]
        errs = sum(1 for c in code for o in c.get("outputs", []) if o.get("output_type") == "error")
        unexecuted = sum(1 for c in code if c.get("execution_count") is None)
        out.append({"name": f"notebook {nb}", "exit_code": 0 if not errs and not unexecuted else 1,
                    "tail": [f"{len(code)} code cells, {errs} error outputs, "
                             f"{unexecuted} unexecuted"], "required": True})
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="hierarchy.cli", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("selfcheck")
    p = sub.add_parser("pilot")
    p.add_argument("--run-id", required=True)
    p.add_argument("--interrupt-after", type=int, default=8)
    p.add_argument("--replay-cases", type=int, default=12)
    p.add_argument("--no-oracle", dest="oracle", action="store_false")
    p = sub.add_parser("freeze")
    p.add_argument("--run-id", required=True)
    p = sub.add_parser("benchmark")
    p.add_argument("--run-id", required=True)
    p.add_argument("--split", required=True)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--quiet", action="store_true")
    for name in ("diagnostics", "report"):
        p = sub.add_parser(name)
        p.add_argument("--run-id", required=True)
    p = sub.add_parser("verify")
    p.add_argument("--run-id", required=True)
    p.add_argument("--full", action="store_true",
                   help="also run tests, lint, guards and notebook checks")
    for name in ("encode", "decode"):
        p = sub.add_parser(name)
        p.add_argument("--input", required=True)
        p.add_argument("--output", required=True)
    a = ap.parse_args(argv)
    return {"selfcheck": cmd_selfcheck, "pilot": cmd_pilot, "freeze": cmd_freeze,
            "benchmark": cmd_benchmark, "diagnostics": cmd_diagnostics, "report": cmd_report,
            "verify": cmd_verify, "encode": cmd_encode, "decode": cmd_decode}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
