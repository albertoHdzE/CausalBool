"""Orchestration of the Phase 2 next round (protocol 1.0): corpora, matrices, journals.

Launches workers; measures nothing itself. Every measured row comes from a
fresh subprocess:

- ``research.next_round_worker`` -- the four ablation cells of the SUCCESSOR
  solver (``next_round_search``), and after Stage E the engineering variant;
- ``research.optimization_worker`` -- the earlier ``cap512_wider`` optimizer,
  unchanged, with its frozen spec (config ``cap512_wider``, build ``cached``,
  search arm ``structural_bound``), through ``optimization_runner.arm_command``;
- ``optimization_frozen_worker.py`` in this run's frozen-control workspace --
  classical, the accepted direct bootstrap and serial (unchanged owners);
- ``research.next_round_profile`` -- separate profiling runs (never timing rows).

Why a Matrix class here rather than the earlier runners' Matrix: those owners
are frozen, hard-code their own protocol's arm-order seed and protocol id, and
cannot charge this round's 24-hour measurement ledger. This one restates their
journal discipline (append + fsync per row, resume only missing keys under an
identical stage manifest) and adds the ledger check before every launch.

Cell order: within each (program, repetition) block, cells are sorted by
``stable_seed([2026092601, program_sha256, repetition, arm_id, budget_or_null])``
(PROTOCOL.json ``seed_keys.arm_order``), ties broken by (arm, budget text).

Usage::

    PYTHONPATH=.reference:. python -m research.next_round_runner --run DIR --stage STAGE
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Dict, List, Optional, Sequence, Tuple

from research import next_round_common as nrc
from research import optimization_common as oc
from research import optimization_runner as orun


WORKER_TIMEOUT = nrc.EXTERNAL_SECONDS
WORK_LIMITS = (1_000, 10_000, 50_000)

# Files imported by this round's workers. A change after a stage starts
# refuses resume (stage manifest) and is reported at stage end.
MEASURED_SOURCES = (
    "research/__init__.py", "research/optimization_common.py",
    "research/objective_index_common.py", "research/next_round_common.py",
    "research/next_round_search.py", "research/next_round_worker.py",
    "research/optimization_search.py", "research/optimization_worker.py",
    "research/optimization_frozen_worker.py", "research/run_structural_experiments.py",
    "research/structural_encoding.py", "research/structural_search.py",
    "research/structural_models.py", "research/structural_oracle.py",
    "research/structural_evidence.py", "research/physical_probes.py",
    "research/classical_measurement_worker.py",
)


# --------------------------------------------------------------------------
# Arms, keys and cell order
# --------------------------------------------------------------------------


def cell_arm(label: str, variant: Optional[str] = None) -> dict:
    cell = nrc.CELLS[label] if variant is None else nrc.CELLS[label.split("+", 1)[0]]
    return {"label": label, "worker": "next", "catalog": cell["catalog"],
            "traversal": cell["traversal"], "variant": variant}


def earlier_arm() -> dict:
    return dict(orun.new_arm(nrc.EARLIER, nrc.EARLIER_SPEC["config"], nrc.EARLIER_SPEC["build"],
                             nrc.EARLIER_SPEC["search_arm"], nrc.EARLIER_SPEC["model_depth"]))


def frozen_arm(label: str) -> dict:
    return orun.frozen_arm(label)


def profile_arm(label: str) -> dict:
    return {"label": label, "worker": "profile", "target": label}


def row_key(program_sha256: str, arm: str, budget, repetition: int) -> str:
    return f"{program_sha256}|{arm}|{budget}|{repetition}"


def order_key(program_sha256: str, repetition: int, arm: str, budget) -> tuple:
    return (nrc.stable_seed([nrc.SEED_ARM_ORDER, program_sha256, repetition, arm, budget]),
            arm, "" if budget is None else str(budget))


def schedule(entries: Sequence[dict], cells: Sequence[Tuple[str, object]], repetitions: int
             ) -> List[Tuple[dict, object, int, str]]:
    """Programs in manifest order, repetitions ascending, cells by stable hash."""

    out = []
    for entry in entries:
        for repetition in range(repetitions):
            for arm, budget in sorted(cells, key=lambda c: order_key(
                    entry["program_sha256"], repetition, c[0], c[1])):
                out.append((entry, budget, repetition, arm))
    return out


def cells_for(unbudgeted: Sequence[str], budgeted: Sequence[str],
              budgets: Sequence[object] = nrc.BUDGETS) -> List[Tuple[str, object]]:
    return [(arm, None) for arm in unbudgeted] + [(arm, b) for arm in budgeted for b in budgets]


def stage_manifest(stage: str, extra: dict, sources: Sequence[str]) -> dict:
    missing = [name for name in sources if oc.file_sha256(oc.ROOT / name) is None]
    if missing:
        raise RuntimeError(f"measured sources missing: {missing}")
    payload = {"stage": stage, "protocol_id": nrc.PROTOCOL_ID,
               "measured_sources": {name: oc.file_sha256(oc.ROOT / name) for name in sources},
               "production": oc.production_source_hashes(),
               "frozen_snapshot": oc.frozen_snapshot_hashes(),
               "python": sys.version, "executable": oc.PYTHON, "extra": extra}
    payload["manifest_sha256"] = oc.object_sha256(payload)
    return payload


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------


def arm_command(run: Path, stage: str, corpus: str, entry: dict, arm: dict, budget,
                repetition: int) -> Tuple[List[str], dict, Path]:
    worker = arm["worker"]
    if worker == "next":
        spec = {"kind": "next_round_measurement", "program_path": entry["program_path"],
                "program_sha256": entry["program_sha256"], "arm": arm["label"],
                "catalog": arm["catalog"], "traversal": arm["traversal"],
                "variant": arm.get("variant"), "repetition": repetition, "stage": stage,
                "corpus": corpus}
        if isinstance(budget, str) and budget.startswith("work:"):
            spec.update(budget_seconds=None, work_limit=int(budget[5:]))
        else:
            spec.update(budget_seconds=budget, work_limit=None)
        argv = [oc.PYTHON, "-m", "research.next_round_worker", "--spec", oc.canonical(spec)]
        return argv, spec, oc.ROOT
    if worker == "profile":
        spec = {"kind": "next_round_profile", "program_path": entry["program_path"],
                "program_sha256": entry["program_sha256"], "arm": arm["label"],
                "target": arm["target"], "budget_seconds": budget, "repetition": repetition,
                "stage": stage, "corpus": corpus}
        argv = [oc.PYTHON, "-m", "research.next_round_profile", "--spec", oc.canonical(spec)]
        return argv, spec, oc.ROOT
    if worker in ("new", "frozen"):
        return orun.arm_command(run, stage, corpus, entry, arm, budget, repetition)
    raise ValueError(f"unknown worker {worker!r}")


# --------------------------------------------------------------------------
# Matrix engine
# --------------------------------------------------------------------------


class CapReached(RuntimeError):
    """The 24-hour measurement ledger is full; the stage stops cleanly."""


class Matrix:
    """One stage's expected keys, cell order, journal, ledger and resume ownership."""

    def __init__(self, run: Path, stage: str, corpus: str, entries: Sequence[dict],
                 arms: Dict[str, dict], cells: Sequence[Tuple[str, object]], repetitions: int,
                 sources: Sequence[str] = MEASURED_SOURCES, extra: Optional[dict] = None,
                 freeze_sha256: Optional[str] = None) -> None:
        self.run = Path(run).resolve()
        self.stage = stage
        self.corpus = corpus
        self.entries = list(entries)
        self.arms = arms
        self.cells = list(cells)
        self.repetitions = repetitions
        self.freeze_sha256 = freeze_sha256
        self.dir = self.run / "stages" / stage
        self.dir.mkdir(parents=True, exist_ok=True)
        self.rows_path = self.dir / "rows.jsonl"
        self.commands_path = self.dir / "commands.jsonl"
        self.plan = schedule(self.entries, self.cells, repetitions)
        self.expected = [row_key(e["program_sha256"], a, b, r) for e, b, r, a in self.plan]
        if len(set(self.expected)) != len(self.expected):
            raise RuntimeError(f"{stage}: duplicate expected keys")
        extra = dict(extra or {}, corpus=corpus, arms=arms,
                     cells=[[a, b] for a, b in self.cells], repetitions=repetitions,
                     programs=[{k: e.get(k) for k in ("seed", "family", "program_sha256",
                                                       "file_sha256", "semantic_sha256")}
                               for e in self.entries],
                     freeze_sha256=freeze_sha256, order_seed=nrc.SEED_ARM_ORDER)
        self.manifest = stage_manifest(stage, extra, sources)

    def write_expected(self) -> None:
        path = self.dir / "EXPECTED_KEYS.json"
        payload = {"stage": self.stage, "count": len(self.expected), "keys": self.expected,
                   "order_seed": nrc.SEED_ARM_ORDER}
        if path.exists():
            if json.loads(path.read_text())["keys"] != self.expected:
                raise RuntimeError(f"{self.stage}: expected key ledger changed")
            return
        oc.write_immutable_json(path, payload)

    def check_manifest(self) -> None:
        path = self.dir / "STAGE_MANIFEST.json"
        if path.exists():
            previous = json.loads(path.read_text())
            if previous["manifest_sha256"] != self.manifest["manifest_sha256"]:
                raise RuntimeError(
                    f"{self.stage}: source/config/environment differs from the stage manifest; "
                    "resume is refused. Preserve these rows as superseded and start afresh.")
            return
        oc.write_immutable_json(path, self.manifest)

    def done_keys(self) -> set:
        return {row["key"] for row in oc.read_rows(self.rows_path)}

    def run_all(self, progress_every: int = 500) -> dict:
        self.check_manifest()
        self.write_expected()
        done = self.done_keys()
        extra_rows = done - set(self.expected)
        if extra_rows:
            raise RuntimeError(f"{self.stage}: journal holds {len(extra_rows)} unexpected keys")
        pending = [item for item, key in zip(self.plan, self.expected) if key not in done]
        oc.append_row(self.dir / "resume_log.jsonl", {
            "event": "start", "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "pid": os.getpid(), "expected": len(self.expected), "already_done": len(done),
            "pending": len(pending), "manifest_sha256": self.manifest["manifest_sha256"],
            "measured_hours_before": nrc.measured_hours(self.run)})
        started = time.perf_counter()
        cap = False
        for count, (entry, budget, repetition, arm_label) in enumerate(pending, 1):
            if nrc.cap_reached(self.run):
                cap = True
                break
            self.run_one(entry, budget, repetition, arm_label)
            if count % progress_every == 0:
                print(f"{self.stage}: {count}/{len(pending)} rows, "
                      f"{time.perf_counter() - started:.0f}s", flush=True)
        done = self.done_keys()
        end_sources = {name: oc.file_sha256(oc.ROOT / name)
                       for name in self.manifest["measured_sources"]}
        unchanged = end_sources == self.manifest["measured_sources"]
        rows = oc.read_rows(self.rows_path)
        summary = {"stage": self.stage, "sources_unchanged_during_stage": unchanged,
                   "expected": len(self.expected), "observed": len(done),
                   "missing": len(set(self.expected) - done),
                   "failed": sum(1 for r in rows if r["failed_row"]),
                   "timed_out": sum(1 for r in rows if r["timed_out"]),
                   "stopped_at_wall_cap": cap,
                   "measured_hours_after": nrc.measured_hours(self.run)}
        oc.append_row(self.dir / "resume_log.jsonl", dict(summary, event="end",
                      utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))
        return summary

    def run_one(self, entry: dict, budget, repetition: int, arm_label: str) -> dict:
        arm = self.arms[arm_label]
        argv, spec, cwd = arm_command(self.run, self.stage, self.corpus, entry, arm, budget,
                                      repetition)
        env = {"PATH": os.environ.get("PATH", ""),
               "PYTHONPATH": f"{oc.ROOT / '.reference'}{os.pathsep}{oc.ROOT}"}
        if arm["worker"] == "frozen":
            env["PYTHONPATH"] = ""
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        started = time.perf_counter()
        timed_out = False
        try:
            proc = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True,
                                  timeout=WORKER_TIMEOUT, env=env)
            stdout, stderr, code = proc.stdout, proc.stderr, proc.returncode
        except subprocess.TimeoutExpired as exc:
            timed_out = True
            stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            code = None
        process_seconds = time.perf_counter() - started
        key = row_key(entry["program_sha256"], arm_label, budget, repetition)
        nrc.charge(self.run, self.stage, key, process_seconds)
        row = {"key": key, "stage": self.stage, "corpus": self.corpus,
               "program_sha256": entry["program_sha256"], "family": entry["family"],
               "seed": entry.get("seed"), "arm": arm_label, "budget_seconds": budget,
               "repetition": repetition, "exit_code": code, "timed_out": timed_out,
               "process_seconds": process_seconds, "stderr_tail": stderr[-4000:],
               "stdout_bytes": len(stdout), "started_utc": stamp,
               "manifest_sha256": self.manifest["manifest_sha256"],
               "freeze_sha256": self.freeze_sha256}
        parsed = None
        if not timed_out and code == 0 and stdout.strip():
            try:
                parsed = json.loads(stdout.strip().splitlines()[-1])
            except json.JSONDecodeError as exc:
                row["failure"] = f"stdout was not one JSON object: {exc}"
        if parsed is not None and str(parsed.get("kind", "")).endswith("_result"):
            result = {k: v for k, v in parsed.items() if k != "kind"}
            for field in ("arm", "budget_seconds", "repetition", "stage", "corpus"):
                result.pop(field, None)
            if result.get("program_sha256") != entry["program_sha256"]:
                row["failure"] = "worker program identity does not match the spec"
            result.pop("program_sha256", None)
            row["result"] = result
            row["cycles"] = result.get("cycles")
            row["scratch"] = result.get("scratch")
            row["product"] = result.get("product")
            row["correctness"] = result.get("correctness", "FAIL")
        else:
            row.setdefault("failure", "worker produced no valid result")
            row["correctness"] = "FAIL"
        row["failed_row"] = bool(row.get("failure")) or row["correctness"] != "PASS"
        oc.append_row(self.commands_path, {
            "key": key, "argv": argv[:-1] + ["<spec>"], "spec": spec, "cwd": str(cwd),
            "env_pythonpath": env["PYTHONPATH"], "exit_code": code, "timed_out": timed_out,
            "process_seconds": process_seconds, "started_utc": stamp,
            "stdout_sha256": oc.sha256_bytes(stdout.encode()),
            "stderr_sha256": oc.sha256_bytes(stderr.encode())})
        oc.append_row(self.rows_path, row)
        return row


# --------------------------------------------------------------------------
# Corpora
# --------------------------------------------------------------------------


def development_entries(run: Path) -> List[dict]:
    return orun.generated_cohort(run, "development", *nrc.DEVELOPMENT)


def profiling_entries(run: Path) -> List[dict]:
    """The first two seeds of each family, in family order (plan section 4)."""

    out: Dict[str, List[dict]] = {}
    for entry in development_entries(run):
        out.setdefault(entry["family"], []).append(entry)
    chosen = []
    for family, entries in out.items():
        chosen.extend(sorted(entries, key=lambda e: e["seed"])[:2])
    if len(chosen) != 10:
        raise RuntimeError("expected ten profiling programs")
    return chosen


def public_entries(run: Path) -> List[dict]:
    return orun.public_cohort(run)


def confirmation_entries(run: Path) -> List[dict]:
    return orun.generated_cohort(run, "confirmation", *nrc.CONFIRMATION)


# --------------------------------------------------------------------------
# Stages
# --------------------------------------------------------------------------


def development_arms() -> Dict[str, dict]:
    arms = {label: cell_arm(label) for label in nrc.CELLS}
    arms[nrc.EARLIER] = earlier_arm()
    return arms


def stage_d_factorial(run: Path) -> Matrix:
    arms = development_arms()
    return Matrix(run, "D_factorial", "development", development_entries(run), arms,
                  cells_for([], list(nrc.DEVELOPMENT_ARMS)), 3)


def stage_d_fixed_work(run: Path) -> Matrix:
    arms = {label: cell_arm(label) for label in nrc.CELLS}
    return Matrix(run, "D_fixed_work", "development_profiling", profiling_entries(run), arms,
                  cells_for([], sorted(nrc.CELLS), [f"work:{n}" for n in WORK_LIMITS]), 1,
                  extra={"work_limits": list(WORK_LIMITS),
                         "wall": "no allowance except the 20 s external safety limit"})


def stage_d_profile(run: Path) -> Matrix:
    arms = {label: profile_arm(label) for label in nrc.DEVELOPMENT_ARMS}
    sources = MEASURED_SOURCES + ("research/next_round_profile.py",)
    return Matrix(run, "D_profile", "development_profiling", profiling_entries(run), arms,
                  cells_for([], list(nrc.DEVELOPMENT_ARMS)), 1, sources=sources,
                  extra={"note": "separate cProfile runs; never used as timing rows"})


STAGES = {
    "D_factorial": stage_d_factorial,
    "D_fixed_work": stage_d_fixed_work,
    "D_profile": stage_d_profile,
}


# --------------------------------------------------------------------------
# Setup and isolation
# --------------------------------------------------------------------------


def isolation_probe(run: Path) -> dict:
    """The owner's frozen/new probe plus what the successor worker actually imports."""

    report = orun.isolation_probe(run)
    code = (
        "import sys, json, hashlib\n"
        f"sys.path[:0] = [{str(oc.ROOT / '.reference')!r}, {str(oc.ROOT)!r}]\n"
        "import research.next_round_worker\n"
        "out = {}\n"
        "for n, m in sorted(sys.modules.items()):\n"
        "    f = getattr(m, '__file__', None)\n"
        "    if f and (n == 'research' or n.startswith('research.') or n in ('machine',"
        "'direct_compiler','direct_contract','direct_optimizer','direct_constraints',"
        "'schema_index','compare_direct')):\n"
        "        out[n] = {'path': f, 'sha256': hashlib.sha256(open(f,'rb').read()).hexdigest()}\n"
        "print(json.dumps(out))\n")
    proc = subprocess.run([oc.PYTHON, "-c", code], cwd=str(oc.ROOT), capture_output=True,
                          text=True, env={"PATH": os.environ.get("PATH", "")})
    modules = json.loads(proc.stdout) if proc.returncode == 0 else None
    report["successor_worker"] = {"exit_code": proc.returncode, "stderr": proc.stderr[-2000:],
                                  "modules": modules}
    workspace = str(orun.frozen_workspace(run))
    ok = (modules is not None
          and "research.next_round_search" in modules
          and "research.objective_index_search" not in modules
          and not any(entry["path"].startswith(workspace) for entry in modules.values()))
    report["successor_worker_loads_successor_only"] = ok
    earlier = (report.get("new") or {}).get("modules") or {}
    report["earlier_worker_search_sha256"] = (earlier.get("research.optimization_search")
                                              or {}).get("sha256")
    report["status"] = "PASS" if report["status"] == "PASS" and ok else "FAIL"
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--stage", required=True,
                        choices=sorted(STAGES) + ["setup", "probe"])
    args = parser.parse_args(argv)
    run = Path(args.run).resolve()
    if args.stage == "setup":
        report = orun.setup_frozen_workspace(run)
        oc.write_json(run / "frozen_control_workspace.json", report)
        print(json.dumps({k: report[k] for k in ("status", "snapshot_mismatches",
                                                  "worker_equal_to_source")}))
        return 0 if report["status"] == "PASS" else 1
    if args.stage == "probe":
        report = isolation_probe(run)
        stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        oc.write_json(run / "isolation" / f"probe_{stamp}.json", report)
        print(json.dumps({k: report.get(k) for k in (
            "status", "frozen_research_from_snapshot", "frozen_production_protected",
            "successor_worker_loads_successor_only", "earlier_worker_search_sha256")}))
        return 0 if report["status"] == "PASS" else 1
    matrix = STAGES[args.stage](run)
    summary = matrix.run_all()
    print(json.dumps(summary))
    return 0 if (summary["missing"] == 0 and summary["sources_unchanged_during_stage"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())
